<?php

// A tag "target" property values
return [
	'_self',
	'_blank',
	'_parent',
	'_top'
];
